#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.h>

#define numeroUSER 100

char nome[numeroUSER][100] = {"ADM"};
int conta[numeroUSER] = {0};
int agencia[numeroUSER] = {0};
float saldo[numeroUSER] = {0};
int senha[numeroUSER] = {1234};
int tipo[numeroUSER] = {1};
int z = 0;
int remover;

int menu(int id_us);
int mostrar();
int logar();
void saque(int id_us);
void transferencia(int id_us);
void menu_adm();
int gravar();
int importar();

int main() {
	setlocale(LC_ALL,"");
    int indice=2;
    int tentativa=0;
    char res='n';
    indice=-1;
    while(tentativa<3)
    {
        if(indice == -1)
        {
            indice = logar();
        }
        if(indice != -1)
        {
            if(tipo[indice] == 0){
                switch(menu(indice)){
                case 1:
                    do{
                        saque(indice);
                        printf("\nDeseja realizar outro saque?");
                        res = getch();
                    }while(res == 's');
                    break;
                case 2:
                    printf("\nSaldo: %.2f\n\n", saldo[indice]);
                    system("PAUSE");
                    break;
                case 3:
                    do{
                        transferencia(indice);
                        printf("\nDeseja realizar outra transferencia? (s/n)");
                        res = getch();
                    }while(res == 's');
                    break;
                case 0:
                    indice = -1;
                    break;
                default:
                    printf("\nEscolha incorreta!");
                }
            }else{
                switch(menu(indice)){
                case 1:
                    do{
                        z++;
                        system("cls");
                        printf("\nDigite o nome do usuario: ");
                        scanf("%s", &nome[z]);
                        printf("\nNumero da conta: ");
                        scanf("%d", &conta[z]);
                        printf("\nDigite a agencia: ");
                        scanf("%d", &agencia[z]);
                        printf("\nDigite o saldo: ");
                        scanf("%f", &saldo[z]);
                        printf("\nDigite a senha: ");
                        scanf("%d", &senha[z]);
                        printf("\nDeseja criar outro usu�rio (s/n): ");
                        res = getch();
                    }while(res == 's');
                    break;
                case 2:
                    int conta_alt, agencia_alt;
                    printf("\nDigite o n�mero da conta: ");
                    scanf("%d",&conta_alt);
                    printf("Digite o n�mero da ag�ncia : ");
                    scanf("%d",&agencia_alt);
                    for(int x=0; x<numeroUSER; x++){
                        if(conta[x] == conta_alt && agencia[x] == agencia_alt){
                            if(x != indice){
                                printf("Digite o novo Saldo: ");
                                scanf("%f", &saldo[x]);
                            }else{
                                printf("N�o � poss�vel alterar o seu valor!!!");
                            }
                        }
                    }
                    break;
                case 3:
                        system("cls");
                        int conta_exc, agencia_exc;
                        printf("\nDigite o numero da conta: ");
                        scanf("%d", &conta_exc);
                        printf("\nDigite o numero da agencia: ");
                        scanf("%d", &agencia_exc);
                        for(int i=0; i<numeroUSER; i++){
                            if(conta[i] == conta_exc && agencia[i] == agencia_exc){
                                conta[i]=-1;
                                agencia[i]=-1;
                                saldo[i]=0;
                                printf("\n\tUsu�rio %s exlu�do com sucesso.\n\n", nome[i]);
                                printf("\nDeseja excluir outro usu�rio (s/n): ");
                                res = getch();
                            }
                       }
                    break;
                case 4:
                	system("cls");
                	mostrar();
                	break;
                case 5:
                	system("cls");
                	gravar();
                	break;
                case 6:
                	system("cls");
                	importar();
                	break;
                case 0:
                    indice = -1;
                    break;
                default:
                    printf("\nEscolha incorreta!");
                }
            }
        }else{
            printf("\nConta ou Agencia nao cadastrada.");
            tentativa++;
            if(tentativa == 2){
                printf("\nVoce so tem mais uma chance de logar no sistema.");
            }
        }
    }
    return 0;
}
int logar(){
    int contaLOG, agenciaLOG, senhaLOG;
    system("cls");
    printf("########################################");
    printf("\nSeja bem vindo ao sistema bancario!");
    printf("\nDigite sua conta: ");
    scanf("%d", &contaLOG);
    printf("\nDigite sua agencia: ");
    scanf("%d", &agenciaLOG);
    printf("\nDigite sua senha: ");
    scanf("%d", &senhaLOG);

    for(int x=0; x<numeroUSER; x++){
        if(agencia[x] == agenciaLOG && conta[x]==contaLOG && senha[x]==senhaLOG){
            return x;
        }
    }
    return -1;
}
int menu(int id_us){
    char escolha;
    system("cls");
    if(tipo[id_us] == 0){
        printf("Usu�rio: %s", nome[id_us]);
        printf("\nSuas op��es s�o:");
        printf("\n1 - Saque");
        printf("\n2 - Saldo");
        printf("\n3 - Transfer�ncia");
    }else{
        printf("Usu�rio ADM: %s", nome[id_us]);
        printf("\nSuas op��es s�o:");
        printf("\n1 - Para criar usuario.");
        printf("\n2 - Para alterar usuario.");
        printf("\n3 - Para excluir usuario.");
        printf("\n4 - Para mostrar usuario.");
        printf("\n5 - Para exportar arquivo.");
        printf("\n6 - Para importar arquivo.");
    }
    printf("\n0 - Sair");
    printf("\nEscolha: ");
    escolha=getch();
    return atoi(&escolha);
}
void transferencia(int id_us){
    float valor_tr=0;
    int conta_tr, agencia_tr, id_ustr;
    int erro = 1;

    printf("\nDigite a conta: ");
    scanf("%d", &conta_tr);
    printf("\nDigite a ag�ncia: ");
    scanf("%d", &agencia_tr);
    printf("\nDigite o valor a ser transferido: ");
    scanf("%f", &valor_tr);

    for(int y=0; y<3; y++){
        if(agencia[y] == agencia_tr && conta[y] == conta_tr){
            id_ustr = y;
            erro = 0;
        }
    }
    if(id_ustr == id_us){
        erro= 1;
    }
    if(valor_tr>saldo[id_us]){
        erro = 2;
    }
    switch(erro){
    case 0:
        saldo[id_us] -= valor_tr;
        saldo[id_ustr] += valor_tr;
        printf("\nTransfer�ncia realizada com sucesso.");
        printf("\nFavorecida: %s", nome[id_ustr]);
        printf("\nO valor de RS %.2f", valor_tr);
        break;
    case 1:
        printf("\nConta ou Ag�ncia inv�lida.");
        break;
    case 2:
        printf("\nSeu saldo � insuficiente.");
        break;
    }
}
void saque(int id_us){
    float valor_sq=0;
    printf("\nDigite o valor: ");
    scanf("%f", &valor_sq);
    if(valor_sq>saldo[id_us]){
        printf("\nSeu saldo � insuficiente.");
    }
    else{
        saldo[id_us] -=valor_sq;
    }
}
int mostrar(){
	char escolha;
	FILE *arq = fopen("Arquivo.txt", "r");
	for(int i=0; i<=z; i++){
		printf("\n-----------------------");
		printf("\nUsuario: %s", nome[i]);
		printf("\nConta: %d", conta[i]);
		printf("\nAg�ncia: %d", agencia[i]);
		printf("\nSaldo: %.2f", saldo[i]);
		printf("\nSenha: %d", senha[i]);
	}
	printf("\n-----------------------");
	printf("\nDeseja retornar ao menu? (s/n): ");
    printf("\nEscolha: ");
    escolha=getch();
    return atoi(&escolha);
	
}
int gravar(){
	char escolha;
	FILE *arq = fopen("Arquivo.txt", "w");
	if(!arq){
		printf("Erro ao exportar o arquivo.");
	}for(int i=0; i<=z; i++){
		fprintf(arq, "%s, %d, %d, %.2f, %d\n", nome[i], conta[i], agencia[i], saldo[i], senha[i]);
	}printf("Dados exportados com sucesso.");
	fclose(arq);
	printf("\nDeseja retornar ao menu? (s/n): ");
    printf("\nEscolha: ");
    escolha=getch();
    return atoi(&escolha);
}
int importar(){
	FILE *arq = fopen("Arquivo.txt", "r");
	char escolha;
	int c;
	while(!feof(arq)){
		for(int i=0; i<=z; i++){
			fscanf(arq, "%s, %d, %d, %.2f, %d", &nome[i], &conta[i], &agencia[i], &saldo[i], &senha[i]);
		}for(int i=0; i<=z; i++){
			printf(nome[i], conta[i], agencia[i], saldo[i], senha[i]);
		}
	}fclose(arq);
	printf("\nDeseja retornar ao menu? (s/n): ");
    printf("\nEscolha: ");
    escolha=getch();
    return atoi(&escolha);
}
