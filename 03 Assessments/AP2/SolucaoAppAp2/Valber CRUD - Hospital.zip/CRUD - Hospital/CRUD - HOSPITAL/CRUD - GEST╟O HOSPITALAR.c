#include<stdio.h>
#include<string.h>
struct ad
{
    char nome[30];
    char doenca[30];
    int cabine,telefone,idade;
} x[100];
int n,i,j=0,a=0,sum=0,g,flag,num;
void read();
void add();
void view();
void search();
void edit();
void del();

int main()
{
    read();//leitura dos dados no arquivo txt
    int c,i,q;
    printf("Gerenciamento de Hospital\n");
    int m,n;
    
    
    while(c!=6)
    {

        printf("**O que deseja fazer ?**\n\n1. Adicionar informacao\n2. Vizualizar informacao\n3. Pesquisar\n4. Editar informacao\n5. Deletar Informacao\n6. Sair\n\nOpcao de escolha=");
        scanf("%d",&c);//Escolha da op��o
        fflush(stdin);
        if(c==1)//adicionar
        {
            system("cls");
            add();
        }
        else if(c==2)//vizualizar
        {
            system("cls");
            view();
        }
        else if(c==3)//pesquisar
        {
            system("cls");
            search();
        }
        else if(c==4)//editar
        {
            system("cls");
            edit();
        }
        else if(c==5)//deletar
        {
            system("cls");
            del();
        }
        else if(c==6) //sa�da do codigo e grava��o do arquivo txt
        {
            write();
            return 0;
        }
        else
        {
            system("cls");
            printf("\n\nEntrada inv�lida , tente novamente ");
        }
        printf("\n\n");
    }
}
void add()
{
    printf("\n\n");
    printf("Dado ja adicionado ao banco de dados numero =%d\n\n",num);//N�mero de pacientes que deseja adicionar 
    printf("Quantas informacoes voce deseja adicionar=\n");
    scanf("%d",&n);
    sum=n+num;

    for(i=num,j=0; i<sum; i++)
    {
        printf("\n");
        fflush(stdin);
        printf("Digite o nome do paciente = ");
        gets(x[i].nome);
        fflush(stdin);
        printf("Qual a doenca do paciente= ");
        gets(x[i].doenca);
        fflush(stdin);
        printf("Qual a idade do paciente = ");
        scanf("%d",&x[i].idade);
        fflush(stdin);
        printf("Qual o numero da cabine do paciente = ");
        scanf("%d",&x[i].cabine);
        fflush(stdin);
        printf("Qual o numero do telefone = ");
        scanf("%d",&x[i].telefone);
        fflush(stdin);
        printf("\n");
        j++;
        a++;
        num++;
    }
}

void view()
{
    for(i=0; i<num; i++)
    {
        printf("\n");
        printf("Numero do registro=%d\n",i);
        printf("Name = ");
        puts(x[i].nome);
        printf("Doenca = ");
        puts(x[i].doenca);
        printf("Numero da cabine = %d\nnumero de telefone = 0%d\nidade=%d",x[i].cabine,x[i].telefone,x[i].idade);
        printf("\n\n");
    }
}
void edit()
{
    int q,p;
    fflush(stdin);
    printf("O que voce quer editar ?\n");
    printf("Faca a sua escolha dentre as opcoes abaixo\n");
    printf("1.Nome\n2.Doenca\n3.idade\n4.Cabine\n5.telefone no.\n");
    printf("Opcao de escolha=");
    scanf("%d",&q);//option
    if(q<=5)
    {
        printf("Digite o numero do registro do paciente= (0 - %d)=",num-1);
        scanf("%d",&p);//Leitura do n�mero do registro do paciente no sistema
        if(p<num)
        {
            if(q==1)
            {
                fflush(stdin);
                printf("Digite o novo nome=");
                gets(x[p].nome);

            }
            else if(q==2)
            {
                fflush(stdin);
                printf("Digite a nova doenca=");
                gets(x[p].doenca);
            }
            else if(q==3)
            {
                fflush(stdin);
                printf("Digite a nova idade=");
                scanf("%d",&x[p].idade);
            }

            else if(q==4)
            {
                fflush(stdin);
                printf("Digite o novo numero da cabine=");
                scanf("%d",&x[p].cabine);
            }

            else if(q==5)
            {
                fflush(stdin);
                printf("Digite o novo numero de telefone =");
                scanf("%d",&x[p].telefone);
            }
        }
        else
        {
            printf("\n\nNumero de registro invalido \nTente novamente !!\n\n");
        }
    }
    else
    {
        printf("\n\nOpcao invalida\nTente novamente!!\n\n");
    }
}
void search()
{
    int s,h,f;
    char u[100];
    printf("Por qual dado voce quer pesquisar ?\n");
    printf("1.Numero do registro.\n2.Nome\n3.doenca\n4.Cabine no.\n5.telefone no.\n6.idade\n\nOpcao de escolha = ");
    scanf("%d",&h);
    if(h==1)
    {
        printf("Digite o numero do registro do paciente=");
        scanf("%d",&s);
        if(s<num)
        {
            printf("\n");
            printf("Numero do registro=%d\n",s);
            printf("Nome = ");
            puts(x[s].nome);
            printf("Doenca = ");
            puts(x[s].doenca);
            printf("Numero da cabine = %d\nNumero de telefone = 0%d\nIdade = %d",x[s].cabine,x[s].telefone,x[s].idade);
            printf("\n\n");
        }
        else
            printf("\n\nNao encontrado\n\n");
    }
    else if(h==2)
    {
        int f=1;
        fflush(stdin);
        printf("Digite o nome do paciente=");
        gets(u);
        fflush(stdin);
        for(g=0; g<num; g++)
        {
            if(strcmp(u,x[g].nome)==0)
            {
                printf("\n");
                printf("Numero do registro=%d\n",g);
                printf("Nome = ");
                puts(x[g].nome);
                printf("Doenca = ");
                puts(x[g].doenca);
                printf("Numero da cabine = %d\nNumero de telefone = 0%d\nIdade = %d",x[g].cabine,x[g].telefone,x[g].idade);
                printf("\n\n");
                f=0;

            }
        }
        if(f==1)
            printf("\nNao encontrado\n");



    }
    else if(h==3)
    {
        int f=1;
        fflush(stdin);
        printf("Digite a doenca do paciente = ");
        gets(u);
        fflush(stdin);
        for(g=0; g<num; g++)
        {
            if(strcmp(u,x[g].doenca)==0)
            {
                printf("\n");
                printf("Numero de registro=%d\n",g);
                printf("Nome = ");
                puts(x[g].nome);
                printf("Doenca = ");
                puts(x[g].doenca);
                printf("Numero da cabine = %d\nNumero de telefone= 0%d\nIdade = %d",x[g].cabine,x[g].telefone,x[g].idade);
                printf("\n\n");
                f=0;
            }


        }
        if(f==1)
            printf("\nNao encontrado\n");


    }
    else if(h==4)
    {
        int f=1;
        printf("Digite o numero da cabine = ");
        scanf("%d",&f);
        for(g=0; g<num; g++)
        {
            if(f==x[g].cabine)
            {
                printf("\n");
                printf("Numero de registro=%d\n",g);
                printf("Nome = ");
                puts(x[g].nome);
                printf("Doenca = ");
                puts(x[g].doenca);
                printf("Numero da cabine = %d\nNumero de telefone = 0%d\nIdade = %d",x[g].cabine,x[g].telefone,x[g].idade);
                printf("\n\n");
                f=0;
            }

        }
        if(f==1)
            printf("Nao encontrado\n\n");

    }
    else if(h==5)
    {
        int f=1;
        printf("Digite o numero de telefone = ");
        scanf("%d",&f);
        for(g=0; g<num; g++)
        {
            if(f==x[g].telefone)
            {
                printf("\n");
                printf("Numero de registro=%d\n",g);
                printf("Nome = ");
                puts(x[g].nome);
                printf("Doenca = ");
                puts(x[g].doenca);
                printf("Numero da cabine = %d\nNumero de telefone = 0%d\nIdade = %d",x[g].cabine,x[g].telefone,x[g].idade);
                printf("\n\n");
                f=0;
            }

        }
        if(f==1)
            printf("Nao encontrado\n\n");
    }
    else if(h==6)
    {
        int f=1;
        printf("Digite a idade do paciente = ");
        scanf("%d",&f);
        for(g=0; g<num; g++)
        {
            if(f==x[g].idade)
            {
                printf("\n");
                printf("Numero de registro=%d\n",g);
                printf("Nome = ");
                puts(x[g].nome);
                printf("Doenca = ");
                puts(x[g].doenca);
                printf("Numero da cabine = %d\nNumero de telefone = 0%d\nIdade = %d",x[g].cabine,x[g].telefone,x[g].idade);
                printf("\n\n");
                f=0;
            }

        }
        if(f==1)
            printf("Nao encontrado\n\n");

    }
    else
        printf("\n\nEntrada invalida\n\n");




}
void del()
{
    int f,h;
    printf("Digite o numero do paciente que voce deseja deletar=");
    scanf("%d",&f);
    if(f<num)
    {
        printf("O que voce quer ?\n");
        printf("1.Remover todo o registro\n2.Remover nome\n3.Remover Doenca\n4.Remover Idade\n5.Remover numero Cabine\n6.Remover Numero de telefone \nOpcao de escolha = ");
        scanf("%d",&h);
        if(h==1)
        {
            while(f<num)
            {
                strcpy(x[f].nome,x[f+1].nome);
                strcpy(x[f].doenca,x[f+1].doenca);
                x[f].idade=x[f+1].idade;
                x[f].cabine=x[f+1].cabine;
                x[f].telefone=x[f+1].telefone;
                f++;
            }
            num--;
        }
        else if(h==2)
        {
            strcpy(x[f].nome,"Cleared");

        }
        else if(h==3)
        {
            strcpy(x[f].doenca,"Cleared");
        }
        else if(h==4)
        {
            x[f].idade=0;
        }
        else if(h==5)
        {
            x[f].cabine=0;
        }
        else if(h==6)
        {
            x[f].telefone=0;
        }

    }
    else
        printf("\n\nNumero de registro invalido\n");

}
void read()
{
    FILE *fp = fopen("paciente.txt","r");
    if(fp == NULL)
    {
        
        fp = fopen("paciente.txt","w");
        fclose(fp);
        printf("File does not exist, I JUST CREATED IT, exiting...\n\n\n");
        return 0;
    }

    num = fread(x, sizeof(struct ad),100, fp);
    fclose(fp);
}
void write()
{
    FILE *fp = fopen("paciente.txt","w");
    if(fp == NULL)
    {
        printf("Error");
        exit(1);
    }
    fwrite(x, sizeof(struct ad),num, fp);

    fclose(fp);
}
