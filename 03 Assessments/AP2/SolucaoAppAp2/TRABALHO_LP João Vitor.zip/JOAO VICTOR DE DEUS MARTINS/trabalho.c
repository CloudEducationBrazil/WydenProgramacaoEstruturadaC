#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <conio.h>									
#define TAM 100
														/*Aluno:Jo�o Victor de Deus Martins
														Mat:171031294	Disciplina:Logica de Programa��o
													    Professor:Heleno Cardoso*/
int i_cad;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct disciplina {
    char  nome[TAM];
    float codigo;
    int  qtdaula,cargah,notamin,notamax;
    char function[TAM];
    char disc[TAM];
    char prof[TAM];
    char sigla[TAM];
    char area_conh[TAM];
    char nivel_ens[TAM];
    char ano_ens[TAM]; 
}disciplina;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
char * cadastrar ( struct disciplina vet_cadastro[TAM], char *nome);
void consult ( struct disciplina vet_cadastro[TAM] );
int alterar ( struct disciplina vet_cadastro[TAM] );
void consult_codigo ( struct disciplina vet_cadastro[TAM] ); 
void consult_ano_ens ( struct disciplina vet_cadastro[TAM] );
int verifica_nome( struct disciplina vet_cadastro[TAM], char *nome );
void listar ( struct disciplina vet_cadastro[TAM] );
int Exportar_dados ( struct disciplina vet_cadastro[TAM] );
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int main ( int argc, char *argv[] ) {

    struct disciplina vet_cadastro[TAM];
    int m;
    char nome[50];
    int num;
    int retorno;
    m = 0;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    do {
    	 printf ( "\t\t\t\t\t<......:::CADASTRO DE DISCIPLINAS:::......> " );
         printf ( "\n\n\t\t\t\t\t      Escolha uma das opcoes abaixo: \n\n" );
         printf ( "[1] >Cadastrar  \n[2] >Consultar \n[3] >Alterar cadastro \n[4] >Listar \n[5] >Exportar em ARQUIVO\n\n[6] |Sair| \n" );
         printf ( "\nOpcao: " );
         scanf ( "%d", &m );
         fflush ( stdin );
        
         switch ( m ) {
            case 1:
                system ( "cls" );
                printf ( "\nNome da Disciplina: " );
                gets (nome);
                retorno = 0;
                retorno = verifica_nome ( vet_cadastro, nome );
                
                if ( retorno == 1 ) {
                
                    cadastrar ( vet_cadastro, nome);
                    printf ( "\n\n\t   Cadastro realizado com sucesso !" );
                    getch();
                    system ( "cls" );
                    break;
                } else {
                    system ( "cls" );
                    printf ( "\n\t Ja cadastrado !" );
                    getch();
                    break;
                }
                
            case 2:
            
                do {
                    system ( "cls" );
                    printf ( "                         \n\n...:::Tipo de Consulta:::..." );
                    printf ( "\n\n\n[1] Consulta por nome \n[2] Consultar por Codigo \n[3] >Voltar< \n" );
                    printf ( "\nOpcao: " );
                    scanf ( "%d", &num );
                    
                    switch ( num ) {
                        case 1:
                            system ( "cls" );
                            consult ( vet_cadastro );
                            getch();
                            system ( "cls" );
                            break;
                            
                        case 2:
                            system ( "cls" );
                            consult_codigo  ( vet_cadastro );
                            getch();
                            system ( "cls" );
                            break;
                            
                        case 3:
                            printf ( "\n\t\t     **Voltando para o Menu**" );
                            printf ( "\n" );
                            getch();
                            system ( "cls" );
                            break;
                            
                        default:
                            system ( "cls" );
                            printf ( "\n\nOpcao Invalida\n\n" );
                            break;
                    }
                } while ( num != 3 );
                
                break;
				      
            case 3:
                system ( "cls" );    
                alterar ( vet_cadastro );
                getch();
                system ( "cls" );
                break;
                
                case 4:
                system ( "cls" );
                listar ( vet_cadastro );
                getch();
                system ( "cls" );
                break;
                
            case 5:
                system ( "cls" );
                
                if ( Exportar_dados ( vet_cadastro ) == -1 )
                    printf ( "ERRO na criacao do Arquivo !\n" );
                    break;
                
                
            case 6:
                system ( "cls" );
                printf ( "\n\n\t\t\t\t** FIM ! **\n\n" );
                break;
                
            default:
                system ( "cls" );
                printf ( "\n\nOpcao Invalida\n\n" );
                break;
                
        }
    } while ( m != 6 );
   
    return 0;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void listar ( disciplina vet_cadastro[] ) {
   
    int i;
    for ( i = 0; i < i_cad; i++ ) {
            
			printf("\nNome da disciplina: %s", vet_cadastro[i].nome);
            printf("\nCodigo: %.1f", vet_cadastro[i].codigo );
            printf("\nNome do Professor: %s",vet_cadastro[i].prof);
            printf("\nSigla da Disciplina: %s",vet_cadastro[i].sigla);
            printf("\nArea de conhecimento: %s",vet_cadastro[i].area_conh);
            printf("\nNivel de ensino: %s",vet_cadastro[i].nivel_ens);
            printf("\nAno de ensino: %s",vet_cadastro[i].ano_ens);
            printf("\nQuantidade de aulas: %d",vet_cadastro[i].qtdaula);
            printf("\nCarga horaria: %d",vet_cadastro[i].cargah);
            printf("\nNota minima: %d",vet_cadastro[i].notamin);
            printf("\nNota maxima: %d",vet_cadastro[i].notamax);
            printf("\n\n");
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
char * cadastrar (struct disciplina vet_cadastro[TAM], char * nome) {

    if ( i_cad == 100 ) return 0;
    
    strcpy ( vet_cadastro[i_cad].nome, nome);
    
    fflush ( stdin );
    		printf ( "Codigo: " );
    		scanf ( "%f", &vet_cadastro[i_cad].codigo  );
    		fflush ( stdin );
    		printf("Nome do Professor: ");
    		gets ( vet_cadastro[i_cad].prof );
			fflush ( stdin );
			printf("Sigla: ");
			gets ( vet_cadastro[i_cad].sigla );
			fflush ( stdin );
    		printf("Area de conhecimento: ");
    		gets ( vet_cadastro[i_cad].area_conh );
			fflush ( stdin );
    		printf("Nivel de ensino: ");
    		gets ( vet_cadastro[i_cad].nivel_ens);
			fflush ( stdin );
    		printf("Ano de ensino: ");
    		gets(vet_cadastro[i_cad].ano_ens);
			fflush( stdin );
    		printf( "Quantidade de aulas no ano letivo: " );
    		scanf("%d",& vet_cadastro[i_cad].qtdaula );
    		fflush( stdin );
    		printf( "Carga horaria por aula: " );
    		scanf("%d",& vet_cadastro[i_cad].cargah );
    		fflush( stdin );
   			printf( "Nota minima para aprovacao: " );
    		scanf("%d",& vet_cadastro[i_cad].notamin );
            fflush ( stdin );
       		printf ( "Nota maxima no periodo: " );
    		scanf ("%d",& vet_cadastro[i_cad].notamax );
    		fflush ( stdin );
    i_cad++;
      
    return "retornar algo";    
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void consult ( struct disciplina vet_cadastro[TAM] ) {

    char nome[30];
    int i = 0;
    
    printf ( "\nDigite o nome: " );
    scanf ( "%s", nome );
    
    for ( i = 0; i < TAM; i++ ) {
        if ( strcmp ( vet_cadastro[i].nome, nome ) == 0 ) {
        
            printf("\nNome da disciplina: %s", vet_cadastro[i].nome);
            printf("\nCodigo: %.1f", vet_cadastro[i].codigo );
            printf("\nNome do Professor: %s",vet_cadastro[i].prof);
            printf("\nSigla da Disciplina: %s",vet_cadastro[i].sigla);
            printf("\nArea de conhecimento: %s",vet_cadastro[i].area_conh);
            printf("\nNivel de ensino: %s",vet_cadastro[i].nivel_ens);
            printf("\nAno de ensino: %s",vet_cadastro[i].ano_ens);
            printf("\nQuantidade de aulas: %d",vet_cadastro[i].qtdaula);
            printf("\nCarga horaria: %d",vet_cadastro[i].cargah);
            printf("\nNota minima: %d",vet_cadastro[i].notamin);
            printf("\nNota maxima: %d",vet_cadastro[i].notamax);
			printf ( "\n\n" );
            return;
            
        } else if ( i == 99 && strcmp (vet_cadastro[99].nome,nome) ) {
            printf ( "\n\tNome nao cadastrado !" );
            return;     
        }
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void consult_codigo  ( struct disciplina vet_cadastro[TAM] ) {

    float codigo ;
    int i = 0;
    
    printf ( "\nInforme o Codigo: " );
    scanf ( "%f", &codigo  );
    
    for ( i = 0; i < TAM; i++ ) {
        if ( vet_cadastro[i].codigo  == codigo  ) {
        
            printf("\nNome da disciplina: %s", vet_cadastro[i].nome);
            printf("\nCodigo: %.1f", vet_cadastro[i].codigo );
            printf("\nNome do Professor: %s",vet_cadastro[i].prof);
            printf("\nSigla da Disciplina: %s",vet_cadastro[i].sigla);
            printf("\nArea de conhecimento: %s",vet_cadastro[i].area_conh);
            printf("\nNivel de ensino: %s",vet_cadastro[i].nivel_ens);
            printf("\nAno de ensino: %s",vet_cadastro[i].ano_ens);
            printf("\nQuantidade de aulas: %d",vet_cadastro[i].qtdaula);
            printf("\nCarga horaria: %d",vet_cadastro[i].cargah);
            printf("\nNota minima: %d",vet_cadastro[i].notamin);
            printf("\nNota maxima: %d",vet_cadastro[i].notamax);
            printf ( "\n\n" );
            return;
            
        } else if ( i == 99 && vet_cadastro[99].codigo  == codigo  ) {
            printf ( "\n\tCodigo  nao cadastrado !" );
            return;
            
        }
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int verifica_nome(struct disciplina vet_cadastro[TAM], char *nome) {

    int i;
    
    for ( i = 0; i < TAM; i++ ) {
        if ( strcmp ( vet_cadastro[i].nome, nome ) == 0 )
            return 0;
    }
    
    return 1;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int alterar ( struct disciplina vet_cadastro[TAM] ) {

    char nome[30];
    int i;
    
    if ( i_cad > 100 ) return 0;
	  
    printf ( "\nEntre com o nome da disciplina que deseja alterar: \n\n" );
    scanf ( "%s", nome );
    
    for ( i = 0; i < TAM; i++ ) {
    
        if ( strcmp ( vet_cadastro[i].nome, nome ) == 0 ) {
            
			fflush ( stdin );
            printf("Nome da Disciplina: ");
    		gets ( vet_cadastro[i].nome);
			fflush ( stdin );
    		printf ( "Codigo: " );
    		scanf ( "%f", &vet_cadastro[i].codigo  );
    		fflush ( stdin );
    		printf("Nome do Professor: ");
    		gets ( vet_cadastro[i].prof );
			fflush ( stdin );
			printf("Sigla: ");
			gets ( vet_cadastro[i].sigla );
			fflush ( stdin );
    		printf("Area de conhecimento: ");
    		gets ( vet_cadastro[i].area_conh );
			fflush ( stdin );
    		printf("Nivel de ensino: ");
    		gets ( vet_cadastro[i].nivel_ens);
			fflush ( stdin );
    		printf("Ano de ensino: ");
    		gets(vet_cadastro[i].ano_ens);
			fflush( stdin );
    		printf( "Quantidade de aulas no ano letivo: " );
    		scanf("%d",& vet_cadastro[i].qtdaula );
    		fflush( stdin );
    		printf( "Carga horaria por aula: " );
    		scanf("%d",& vet_cadastro[i].cargah );
    		fflush( stdin );
   			printf( "Nota minima para aprovacao: " );
    		scanf("%d",& vet_cadastro[i].notamin );
            fflush ( stdin );
       		printf ( "Nota maxima no periodo: " );
    		scanf ("%d",& vet_cadastro[i].notamax );
    		fflush ( stdin ); 
    		
			break;          
        }
    }
    return 0;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int Exportar_dados ( disciplina vet_cadastro[] ) {
    FILE* file;
    
    if ( !(file = fopen("cadastro.txt", "w"))){
        perror("Erro ");
        getchar();
        return ( -1 );  
    }
    int i;
    for ( i = 0; i < i_cad; i++ ) {

            fprintf(file,"\nNome da disciplina: %s", vet_cadastro[i].nome);
            fprintf(file,"\nCodigo: %.1f", vet_cadastro[i].codigo );
            fprintf(file,"\nNome do Professor: %s",vet_cadastro[i].prof);
            fprintf(file,"\nSigla da Disciplina: %s",vet_cadastro[i].sigla);
            fprintf(file,"\nArea de conhecimento: %s",vet_cadastro[i].area_conh);
            fprintf(file,"\nNivel de ensino: %s",vet_cadastro[i].nivel_ens);
            fprintf(file,"\nAno de ensino: %s",vet_cadastro[i].ano_ens);
            fprintf(file,"\nQuantidade de aulas: %d",vet_cadastro[i].qtdaula);
            fprintf(file,"\nCarga horaria: %d",vet_cadastro[i].cargah);
            fprintf(file,"\nNota minima: %d",vet_cadastro[i].notamin);
            fprintf(file,"\nNota maxima: %d",vet_cadastro[i].notamax);    
    }    
    fclose ( file );
    return ( 1 );
}

